from flask import Flask, render_template, redirect, session, request  
app = Flask(__name__)